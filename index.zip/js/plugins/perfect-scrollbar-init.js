$(function () {
    // const ps1 = new PerfectScrollbar('.trade-balance');    
    const ps2 = new PerfectScrollbar('.budget-content');
    const ps3 = new PerfectScrollbar('.invoice-content');
    // const ps3 = new PerfectScrollbar('.transaction-table');
});